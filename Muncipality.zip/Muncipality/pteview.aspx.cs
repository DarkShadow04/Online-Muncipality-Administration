﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;

public partial class pteview : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string employee2 = (string)Session["employee1"];
        string depart2 = (string)Session["depart1"];
        string sop2 = (string)Session["sop1"];
        string bp2 = (string)Session["bp1"];
        string da2 = (string)Session["da1"];
        string d2 = (string)Session["d1"];
        string doj2 = (string)Session["doj1"];
        string deb2 = (string)Session["deb1"];
        string designt2 = (string)Session["designt1"];
        string ed2 = (string)Session["ed1"];

        Label11.Text = employee2.ToString();
        Label13.Text = depart2.ToString();
        Label12.Text = sop2.ToString();
        Label14.Text = bp2.ToString();
        Label15.Text = da2.ToString();
        Label23.Text = d2.ToString();
        Label16.Text = doj2.ToString();
        Label17.Text = deb2.ToString();
        Label18.Text = designt2.ToString();
        Label19.Text = ed2.ToString();

        int tax = 0;
        double bp = double.Parse(bp2.ToString());
        double da = double.Parse(da2.ToString());
        double t = bp + da;
        double h = t * 6;
        Label24.Text = t.ToString();
        Label12.Text = h.ToString();
        if (h < 12000)
        {
            tax = 0;
        }
        else if (h > 12000 && h < 17999)
        {
            tax = 120;
        }
        else if (h > 18000 && h < 29999)
        {
            tax = 180;
        }
        else if (h > 30000 && h < 44999)
        {
            tax = 300;
        
        }
        else if (h > 45000 && h < 59999)
        {
            tax = 450;
        }
        else if (h > 60000 && h < 74999)
        {
            tax = 600;
        }
        else if (h > 75000 && h < 99999)
        {
            tax = 750;
        }
        else if (h > 100000 && h < 124999)
        {
            tax = 1000;
        }
        else if (h > 125000)
        {
            tax = 1250;
        }
        Label12.Text = tax.ToString();
    
        using (StreamReader f = new StreamReader("d:\\muncipality\\empid"))
        {
            String k = f.ReadToEnd();
            int k1 = int.Parse(k.ToString());
            k1 = k1 + 1;
            Label20.Text = k1.ToString();
        }

        using (StreamWriter f1 = new StreamWriter("d:\\muncipality\\empid"))
        {

            f1.Write(Label20.Text.ToString());
            f1.Close();





        }
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();






        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "insert into ptei(empid,empname,depart,sop,bp,da,d,doj,deb,designt,ed,t) values('" + Label20.Text.ToString() + "','" + Label11.Text.ToString() + "','" + Label13.Text.ToString() + "','" + Label12.Text.ToString() + "','" + Label14.Text.ToString() + "','" + Label15.Text.ToString() + "','" + Label23.Text.ToString() + "','" + Label16.Text.ToString() + "','" + Label17.Text.ToString() + "','" + Label18.Text.ToString() + "','" + Label19.Text.ToString() + "','" + Label24.Text.ToString() + "')";

        s.ExecuteNonQuery();

        Response.Write("<marquee>Successfully Save</marquee>");

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;

public partial class munirec : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        string mname2 = (string)Session["mname1"];
        string district2 = (string)Session["district1"];
        string address2 = (string)Session["address1"];
        string pno2 = (string)Session["pno1"];
        string email2 = (string)Session["email1"];
        string fax2 = (string)Session["fax1"];
        string chairman2 = (string)Session["chairman1"];
        string contact2 = (string)Session["contact1"];
        string username2 = (string)Session["username1"];
        string password2 = (string)Session["password1"];
        string h2 = (string)Session["h1"];
        string hint2 = (string)Session["hint1"];

        Label1.Text = mname2.ToString();
        Label2.Text = district2.ToString();
        Label3.Text = address2.ToString();
        Label4.Text = pno2.ToString();
        Label5.Text = email2.ToString();
        Label6.Text = fax2.ToString();
        Label7.Text = chairman2.ToString();
        Label8.Text = contact2.ToString();



        using (StreamReader f = new StreamReader("d:\\muncipality\\mid")) 
        {
            String k = f.ReadToEnd();
            int k1 = int.Parse(k.ToString());
            k1 = k1 + 1;
            Label9.Text = k1.ToString();
        }

        using (StreamWriter f1 = new StreamWriter("d:\\muncipality\\mid")) 
        {

            f1.Write(Label9.Text.ToString());

        }
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "insert into muninfo(munid,mname,district,address,phone,email,fax,chairman,contact,username,password,hintq,hinta) values('" + Label9.Text.ToString() + "','" + Label1.Text.ToString() + "','" + Label2.Text.ToString() + "','" + Label3.Text.ToString() + "','" + Label4.Text.ToString() + "','" + Label5.Text.ToString() + "','" + Label6.Text.ToString() + "','" + Label7.Text.ToString() + "','" + Label8.Text.ToString() + "','" + username2.ToString() + "','" + password2.ToString() + "','" + h2.ToString() + "','" + hint2.ToString() + "')";

        s.ExecuteNonQuery();

    }

    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
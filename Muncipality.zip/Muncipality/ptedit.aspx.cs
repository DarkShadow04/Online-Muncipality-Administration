﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class ptedit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
            o.Open();

            SqlDataAdapter objdataadapter = new SqlDataAdapter("select* from ptei", o);
            DataSet objdataset = new DataSet();
            objdataadapter.Fill(objdataset, "ptei");
            
            foreach (DataTable table in objdataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    DropDownList2.Items.Add(row["empid"].ToString());
                }
            }
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        {
            SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
            o.Open();

            SqlDataAdapter objdataadapter = new SqlDataAdapter("select* from ptei", o);
            DataSet objdataset = new DataSet();
            objdataadapter.Fill(objdataset, "ptei");
            int f = 0;
            foreach (DataTable table in objdataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {

                    if (DropDownList2.Text.ToString().ToUpper().Trim().Equals(row["empid"].ToString().ToUpper().Trim()))
                    {
                        f = 1;
                        TextBox1.Text = row["empname"].ToString();
                        TextBox2.Text = row["sop"].ToString();
                        DropDownList1.Text = row["depart"].ToString();
                        TextBox4.Text = row["bp"].ToString();
                        TextBox5.Text = row["da"].ToString();
                        TextBox7.Text = row["doj"].ToString();
                        TextBox8.Text = row["deb"].ToString();
                        TextBox9.Text = row["designt"].ToString();
                        TextBox10.Text = row["ed"].ToString();
                        break;


                    }
                    if (f == 1)
                        break;


                }
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "update ptei set empname='" + TextBox1.Text.ToString() + "', sop='" + TextBox2.Text.ToString() + "', depart='" + DropDownList1.Text.ToString() + "',   bp='" + TextBox4.Text.ToString() + "', da='" + TextBox5.Text.ToString() + "',d='" + TextBox6.Text.ToString() + "', doj='" + TextBox7.Text.ToString() + "', deb='" + TextBox8.Text.ToString() + "', designt='" + TextBox9.Text.ToString() + "', ed='" + TextBox10.Text.ToString() + "' where empid='" + DropDownList2.Text.ToString() + "'";
        s.ExecuteNonQuery();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "delete from ptei where empid='" + DropDownList2.Text.ToString() + "'";
        s.ExecuteNonQuery();
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        double d = double.Parse(TextBox4.Text.ToString()) + double.Parse(TextBox4.Text.ToString()) * double.Parse(TextBox5.Text.ToString()) / 100;
        TextBox6.Text = d.ToString();
    }


    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
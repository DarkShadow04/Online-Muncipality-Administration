﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class taxedit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
            o.Open();

            SqlDataAdapter objdataadapter = new SqlDataAdapter("select* from tax", o);
            DataSet objdataset = new DataSet();
            objdataadapter.Fill(objdataset, "tax");

            GridView1.DataSource = objdataset;
            GridView1.DataMember = "tax";
            GridView1.DataBind();

            
            foreach (DataTable table in objdataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    DropDownList1.Items.Add(row["deffect"].ToString());
                }
            }
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

        {
           

        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();
        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "update tax set fm='" + TextBox5.Text.ToString() + "', t='" + TextBox6.Text.ToString() + "',hyt='" + TextBox7.Text.ToString() + "' where deffect='" + DropDownList1.Text.ToString() + "'";
        s.ExecuteNonQuery();
    }

    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "delete from tax where deffect='" + DropDownList1.Text.ToString() + "'";
        s.ExecuteNonQuery();
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
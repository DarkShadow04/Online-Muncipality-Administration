﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;

public partial class taxinti : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
            o.Open();

            SqlDataAdapter objdataadapter = new SqlDataAdapter("select* from mundep", o);
            DataSet objdataset = new DataSet();
            objdataadapter.Fill(objdataset, "mundep");




            foreach (DataTable table in objdataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    DropDownList1.Items.Add(row["depame"].ToString());
                    DropDownList2.Items.Add(row["regno"].ToString());
                }
            }
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlDataAdapter objdataadapter = new SqlDataAdapter("select * from mundep where depame='" + DropDownList1.Text.ToString() + "'", o);
        DataSet objdataset = new DataSet();
        objdataadapter.Fill(objdataset, "mundep");

        GridView1.DataSource = objdataset;
        GridView1.DataMember = "mundep";
        GridView1.DataBind();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}

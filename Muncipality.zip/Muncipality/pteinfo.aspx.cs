﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class pteinfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["employee1"] = TextBox1.Text.ToString();
        Session["depart1"] = DropDownList1.Text.ToString();
        Session["sop1"] = TextBox2.Text.ToString();
        Session["bp1"] = TextBox4.Text.ToString();
        Session["da1"] = TextBox5.Text.ToString();
        Session["d1"] = TextBox6.Text.ToString();
        Session["doj1"] = TextBox7.Text.ToString();
        Session["deb1"] = TextBox8.Text.ToString();
        Session["designt1"] = TextBox9.Text.ToString();
        Session["ed1"] = TextBox10.Text.ToString();

        Response.Redirect("pteview.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
       double d= double.Parse(TextBox4.Text.ToString()) + double.Parse(TextBox4.Text.ToString()) * double.Parse(TextBox5.Text.ToString()) /100;
        TextBox6.Text = d.ToString();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = " ";
        TextBox2.Text = " ";
        TextBox4.Text = " ";
        TextBox5.Text = " ";
        TextBox6.Text = " ";
        TextBox7.Text = " ";
        TextBox8.Text = " ";
        TextBox9.Text = " ";
        TextBox10.Text = " ";
    }

   
     protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlDataAdapter objdataadapter = new SqlDataAdapter("select * from mundep where depame='" + DropDownList1.Text.ToString() + "'", o);
        DataSet objdataset = new DataSet();

        objdataadapter.Fill(objdataset, "mundep");

        foreach (DataTable table in objdataset.Tables)
        {
            foreach (DataRow row in table.Rows)
            {
                DropDownList1.Items.Add(row["depame"].ToString());
            }
        }
    }

    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}

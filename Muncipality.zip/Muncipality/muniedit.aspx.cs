﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class muniedit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
            o.Open();

            SqlDataAdapter objdataadapter = new SqlDataAdapter("select* from muninfo", o);
            DataSet objdataset = new DataSet();
            objdataadapter.Fill(objdataset, "muninfo");
          
            foreach (DataTable table in objdataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    DropDownList2.Items.Add(row["munid"].ToString());
                }
            }
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

        {
            SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
            o.Open();

            SqlDataAdapter objdataadapter = new SqlDataAdapter("select* from muninfo", o);
            DataSet objdataset = new DataSet();
            objdataadapter.Fill(objdataset, "muninfo");
            int f = 0;
            foreach (DataTable table in objdataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {

                    if (DropDownList2.Text.ToString().ToUpper().Trim().Equals(row["munid"].ToString().ToUpper().Trim()))
                    {
                        f = 1;
                        TextBox1.Text = row["Mname"].ToString();
                        TextBox9.Text = row["district"].ToString();
                        TextBox3.Text = row["address"].ToString();
                        TextBox4.Text = row["phone"].ToString();
                        TextBox5.Text = row["email"].ToString();
                        TextBox7.Text = row["fax"].ToString();
                        TextBox6.Text = row["chairman"].ToString();
                        TextBox8.Text = row["contact"].ToString();
                        break;


                    }
                    if (f == 1)
                        break;


                }
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
      
   SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();
        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "update muninfo set mname='" + TextBox1.Text.ToString() + "', district='" + TextBox9.Text.ToString() + "', address='" + TextBox3.Text.ToString() + "',   phone='" + TextBox4.Text.ToString() + "', email='" + TextBox5.Text.ToString() + "', fax='" + TextBox7.Text.ToString() + "', chairman='" + TextBox6.Text.ToString() + "', contact='" + TextBox8.Text.ToString() + "' where munid='" + DropDownList2.Text.ToString() + "'";
        s.ExecuteNonQuery();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "delete from muninfo where munid='" + DropDownList2.Text.ToString() + "'";
        s.ExecuteNonQuery();
    }



    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
   

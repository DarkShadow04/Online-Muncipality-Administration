﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class taxinfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["fm1"] = TextBox1.Text.ToString();
        Session["t1"] = TextBox2.Text.ToString();
        Session["hyt1"] = TextBox3.Text.ToString();
        Session["deffect1"] = TextBox4.Text.ToString();

        Response.Redirect("taxview.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {

    }

    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class taxpay : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
            o.Open();

            SqlDataAdapter objdataadapter = new SqlDataAdapter("select* from ptei", o);
            DataSet objdataset = new DataSet();
            objdataadapter.Fill(objdataset, "ptei");

            foreach (DataTable table in objdataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    DropDownList1.Items.Add(row["depart"].ToString());
                    DropDownList3.Items.Add(row["empid"].ToString());
                }
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        int amnt1 = int.Parse(Label14.Text.ToString());


        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();


        SqlDataAdapter objdataadapter = new SqlDataAdapter("select * from dummy where acnt='" + TextBox5.Text.ToString() + "'", o);
        DataSet objdataset = new DataSet();
        objdataadapter.Fill(objdataset, "ptei");

        int f = 0;

        foreach (DataTable table in objdataset.Tables)
        {
            foreach (DataRow row in table.Rows)
            {
                if (TextBox5.Text.ToString().ToUpper().Trim().Equals(row["acnt"].ToString().ToUpper().Trim()))
                {
                    f = 1;
                    string a = row["amnt"].ToString();
                    int amnt2 = int.Parse(a.ToString());
                    int d = amnt2 - amnt1;
                    SqlCommand s = new SqlCommand();
                    s.Connection = o;

                    s.CommandText = "update dummy set amnt='" + d.ToString() + "'where acnt='" + TextBox5.Text.ToString() + "'";
                    s.ExecuteNonQuery();
                    break;
                }
                if (f == 1)
                    break;
            }



            
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlDataAdapter objdataadapter = new SqlDataAdapter("select * from ptei where depart='" + DropDownList1.Text.ToString() + "'", o);
        DataSet objdataset = new DataSet();
        objdataadapter.Fill(objdataset, "ptei");
    }


    protected void Button2_Click(object sender, EventArgs e)
    {

        TextBox5.Text = " ";
        TextBox6.Text = " ";
        TextBox7.Text = " ";
        TextBox8.Text = " ";

    }

    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlDataAdapter objdataadapter = new SqlDataAdapter("select * from ptei where empid='" + DropDownList3.Text.ToString() + "'", o);
        DataSet objdataset = new DataSet();
        objdataadapter.Fill(objdataset, "ptei");

        int f = 0;

        foreach (DataTable table in objdataset.Tables)
        {
            foreach (DataRow row in table.Rows)
            {
                if (DropDownList3.Text.ToString().ToUpper().Trim().Equals(row["empid"].ToString().ToUpper().Trim()))
                {
                    f = 1;
                    Label13.Text = row["doj"].ToString();
                    Label14.Text = row["t"].ToString();
                    break;
                }
                if (f == 1)
                    break;
            }
            if (f == 0)
                Response.Write("<marquee> sorry data not found</marquee>");
            }
        }

    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("homeuser.aspx");
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}

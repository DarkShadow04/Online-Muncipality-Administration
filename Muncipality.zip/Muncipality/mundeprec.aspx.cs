﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;


public partial class mundeprec : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        string depame2 = (string)Session["depame1"];
        string head2 = (string)Session["head1"];
        string desig2 = (string)Session["desig1"];
        string dor2 = (string)Session["dor1"];
        string regno2 = (string)Session["regno1"];
        string address2 = (string)Session["address1"];
        string email2 = (string)Session["email1"];
        string fax2 = (string)Session["fax1"];
        string phone2 = (string)Session["phone1"];
        string username2 = (string)Session["username1"];
        string password2 = (string)Session["password1"];
        string hq2 = (string)Session["hq1"];
        string ha2 = (string)Session["ha1"];

        Label2.Text = depame2.ToString();
        Label3.Text = head2.ToString();
        Label4.Text = desig2.ToString();
        Label5.Text = dor2.ToString();
        Label6.Text = regno2.ToString();
        Label7.Text = address2.ToString();
        Label8.Text = email2.ToString();
        Label9.Text = fax2.ToString();
        Label10.Text = phone2.ToString();



        using (StreamReader f = new StreamReader("d:\\muncipality\\depid"))
        {
            String k = f.ReadToEnd();
            int k1 = int.Parse(k.ToString());
            k1 = k1 + 1;
            Label1.Text = k1.ToString();
        }

        using (StreamWriter f1 = new StreamWriter("d:\\muncipality\\depid"))
        {

            f1.Write(Label1.Text.ToString());

        }
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "insert into mundep(depid,depame,head,desig,dor,regno,address,email,fax,phone,username,password,hq,ha) values('" + Label1.Text.ToString() + "','" + Label2.Text.ToString() + "','" + Label3.Text.ToString() + "','" + Label4.Text.ToString() + "','" + Label5.Text.ToString() + "','" + Label6.Text.ToString() + "','" + Label7.Text.ToString() + "','" + Label8.Text.ToString() + "','" + Label9.Text.ToString() + "','" + Label10.Text.ToString() + "','" + username2.ToString() + "','" + password2.ToString() + "','" + hq2.ToString() + "','" + ha2.ToString() + "')";

        s.ExecuteNonQuery();
    }

    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
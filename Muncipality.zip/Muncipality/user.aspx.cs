﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;

public partial class user : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();
        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "insert into user1(id,pswd,name,pno,email) values('" + TextBox9.Text.ToString() + "','" + TextBox10.Text.ToString() + "','" + TextBox13.Text.ToString() + "','" + TextBox12.Text.ToString() + "','" + TextBox11.Text.ToString() + "')";

        s.ExecuteNonQuery();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox9.Text = " ";
        TextBox10.Text = " ";
        TextBox13.Text = " ";
        TextBox12.Text = " ";
        TextBox11.Text = " ";
    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("userlogin.aspx");
    }

    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
}
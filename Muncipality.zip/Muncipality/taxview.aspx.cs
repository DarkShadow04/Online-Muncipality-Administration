﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class taxview : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string fm2 = (string)Session["fm1"];
        string t2 = (string)Session["t1"];
        string hyt2 = (string)Session["hyt1"];
        string deffect2 = (string)Session["deffect1"];
               
        Label1.Text = fm2.ToString();
        Label2.Text = t2.ToString();
        Label3.Text = hyt2.ToString();
        Label4.Text = deffect2.ToString();


        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "insert into tax(fm,t,hyt,deffect) values('" + Label1.Text.ToString() + "','" + Label2.Text.ToString() + "','" + Label3.Text.ToString() + "','" + Label4.Text.ToString() + "')";

        s.ExecuteNonQuery();

    }


    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
    
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class mundep : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
            }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["depame1"] = TextBox1.Text.ToString();
        Session["head1"] = TextBox2.Text.ToString();
        Session["desig1"] = TextBox3.Text.ToString();
        Session["dor1"] = TextBox4.Text.ToString();
        Session["regno1"] = TextBox5.Text.ToString();
        Session["address1"] = TextBox6.Text.ToString();
        Session["email1"] = TextBox7.Text.ToString();
        Session["fax1"] = TextBox8.Text.ToString();
        Session["phone1"] = TextBox9.Text.ToString();
        Session["username1"] = TextBox10.Text.ToString();
        Session["password1"] = TextBox11.Text.ToString();
        Session["hq1"] = DropDownList1.Text.ToString();
        Session["ha1"] = TextBox14.Text.ToString();

        Response.Redirect("mundeprec.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = " ";
        TextBox2.Text = " ";
        TextBox3.Text = " ";
        TextBox4.Text = " ";
        TextBox5.Text = " ";
        TextBox6.Text = " ";
        TextBox7.Text = " ";
        TextBox8.Text = " ";
        TextBox9.Text = " ";
        TextBox10.Text = " ";
        TextBox11.Text = " ";
        TextBox12.Text = " ";
        TextBox14.Text = " ";

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
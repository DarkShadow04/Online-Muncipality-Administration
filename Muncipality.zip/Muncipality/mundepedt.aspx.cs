﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class mundepedt : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
            o.Open();

            SqlDataAdapter objdataadapter = new SqlDataAdapter("select* from mundep", o);
            DataSet objdataset = new DataSet();
            objdataadapter.Fill(objdataset, "mundep");
           
            foreach (DataTable table in objdataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    DropDownList2.Items.Add(row["depid"].ToString());
                }
            }
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        {
            SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
            o.Open();

            SqlDataAdapter objdataadapter = new SqlDataAdapter("select* from mundep", o);
            DataSet objdataset = new DataSet();
            objdataadapter.Fill(objdataset, "mundep");
            int f = 0;
            foreach (DataTable table in objdataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {

                    if (DropDownList2.Text.ToString().ToUpper().Trim().Equals(row["depid"].ToString().ToUpper().Trim()))
                    {
                        f = 1;
                        TextBox1.Text = row["depame"].ToString();
                        TextBox2.Text = row["head"].ToString();
                        TextBox3.Text = row["desig"].ToString();
                        TextBox4.Text = row["dor"].ToString();
                        TextBox5.Text = row["regno"].ToString();
                        TextBox6.Text = row["address"].ToString();
                        TextBox7.Text = row["email"].ToString();
                        TextBox8.Text = row["fax"].ToString();
                        TextBox9.Text = row["phone"].ToString();
                        break;


                    }
                    if (f == 1)
                        break;


                }
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "update mundep set depame='" + TextBox1.Text.ToString() + "', head='" + TextBox2.Text.ToString() + "', desig='" + TextBox3.Text.ToString() + "',   dor='" + TextBox4.Text.ToString() + "', regno='" + TextBox5.Text.ToString() + "', address='" + TextBox6.Text.ToString() + "', email='" + TextBox7.Text.ToString() + "', fax='" + TextBox8.Text.ToString() + "', phone='" + TextBox9.Text.ToString() + "' where depid='" + DropDownList2.Text.ToString() + "'";
        s.ExecuteNonQuery();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection o = new SqlConnection("Data Source=DARK\\SQLEXPRESS; Initial Catalog = munsip; Integrated Security=true");
        o.Open();

        SqlCommand s = new SqlCommand();
        s.Connection = o;

        s.CommandText = "delete from mundep where depid='" + DropDownList2.Text.ToString() + "'";
        s.ExecuteNonQuery();
    }



    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}